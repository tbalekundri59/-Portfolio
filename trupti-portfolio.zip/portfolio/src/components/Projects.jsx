import { useState } from 'react';
import { Github, ExternalLink, ArrowRight } from 'lucide-react';
import projects from '../data/projects.js';
import ProjectModal from './ProjectModal.jsx';

export default function Projects() {
  const [activeProject, setActiveProject] = useState(null);

  return (
    <section id="projects" className="py-24 bg-ink-900/[0.02] dark:bg-paper-100/[0.02]">
      <div className="max-w-content mx-auto px-6 lg:px-10">
        <h2 className="font-display font-bold text-3xl lg:text-4xl">Projects</h2>
        <p className="mt-3 opacity-70 max-w-xl">
          Full-stack applications built end to end — from database schema to
          responsive UI.
        </p>

        <div className="mt-10 grid md:grid-cols-2 gap-6">
          {projects.map((project) => (
            <article
              key={project.id}
              className="reveal group border border-ink-700/15 dark:border-paper-100/15 rounded-lg p-6 lg:p-7 flex flex-col hover:border-amber/60 transition-colors"
            >
              <h3 className="font-display font-semibold text-xl">{project.name}</h3>
              <p className="font-mono text-xs text-teal mt-1">{project.subtitle}</p>

              <p className="mt-4 text-sm leading-relaxed opacity-80">{project.description}</p>

              <div className="mt-5 flex flex-wrap gap-1.5">
                {project.tech.slice(0, 6).map((t) => (
                  <span
                    key={t}
                    className="text-[11px] font-mono px-2 py-1 rounded border border-ink-700/15 dark:border-paper-100/15 opacity-70"
                  >
                    {t}
                  </span>
                ))}
                {project.tech.length > 6 && (
                  <span className="text-[11px] font-mono px-2 py-1 opacity-50">
                    +{project.tech.length - 6} more
                  </span>
                )}
              </div>

              <div className="mt-6 flex items-center gap-4 text-sm">
                <button
                  onClick={() => setActiveProject(project)}
                  className="inline-flex items-center gap-1.5 font-medium text-amber hover:gap-2.5 transition-all"
                >
                  View details <ArrowRight size={15} />
                </button>

                <ProjectLink href={project.githubUrl} icon={<Github size={15} />} label="Code" />
                <ProjectLink href={project.liveUrl} icon={<ExternalLink size={15} />} label="Live" />
              </div>
            </article>
          ))}
        </div>
      </div>

      {activeProject && (
        <ProjectModal project={activeProject} onClose={() => setActiveProject(null)} />
      )}
    </section>
  );
}

function ProjectLink({ href, icon, label }) {
  if (!href) {
    return (
      <span className="inline-flex items-center gap-1.5 opacity-35 cursor-not-allowed" title="Link not yet added">
        {icon} {label}
      </span>
    );
  }
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="inline-flex items-center gap-1.5 opacity-70 hover:opacity-100 hover:text-amber transition-colors"
    >
      {icon} {label}
    </a>
  );
}
