import { GraduationCap, MapPin, Mail } from 'lucide-react';
import profile from '../data/profile.js';

export default function About() {
  return (
    <section id="about" className="py-24 spine">
      <div className="max-w-content mx-auto px-6 lg:px-10 pl-10 lg:pl-14 relative">
        <span className="spine-node" style={{ top: 6 }} />
        <h2 className="font-display font-bold text-3xl lg:text-4xl">About</h2>

        <div className="mt-10 grid lg:grid-cols-[1.3fr_1fr] gap-12">
          <div className="space-y-5 text-base leading-relaxed opacity-85 max-w-2xl">
            <p>{profile.summary}</p>
            <p>
              Currently completing a Bachelor of Engineering in Computer
              Science at {profile.education.institute}, with a CGPA of{' '}
              {profile.education.cgpa}, graduating in {profile.education.duration.split('–')[1].trim()}.
              Development experience spans two internships — building
              full-stack Java applications with Spring Boot, JDBC, Servlets,
              and relational databases, and working with Linux, Git, Docker,
              and CI/CD pipelines in a cloud DevOps context.
            </p>
          </div>

          <div className="border border-ink-700/15 dark:border-paper-100/15 rounded-lg p-6 font-body h-fit">
            <h3 className="font-mono text-sm opacity-50 mb-4">// quick facts</h3>
            <dl className="space-y-4 text-sm">
              <Fact icon={<GraduationCap size={16} />} label="Degree">
                {profile.education.degree}
              </Fact>
              <Fact label="Institute">{profile.education.institute}</Fact>
              <Fact label="CGPA">{profile.education.cgpa}</Fact>
              <Fact label="Graduation">2026</Fact>
              <Fact icon={<MapPin size={16} />} label="Location">
                {profile.location}
              </Fact>
              <Fact icon={<Mail size={16} />} label="Email">
                <a href={`mailto:${profile.email}`} className="hover:text-amber break-all">
                  {profile.email}
                </a>
              </Fact>
            </dl>
          </div>
        </div>
      </div>
    </section>
  );
}

function Fact({ icon, label, children }) {
  return (
    <div className="flex items-start justify-between gap-4 border-b border-ink-700/10 dark:border-paper-100/10 pb-3">
      <dt className="opacity-60 flex items-center gap-2">
        {icon}
        {label}
      </dt>
      <dd className="text-right font-medium">{children}</dd>
    </div>
  );
}
