import { Github, Linkedin, Mail } from 'lucide-react';
import profile from '../data/profile.js';

export default function Footer() {
  return (
    <footer className="border-t border-ink-700/10 dark:border-paper-100/10 py-10">
      <div className="max-w-content mx-auto px-6 lg:px-10 flex flex-col sm:flex-row items-center justify-between gap-6">
        <div className="text-center sm:text-left">
          <p className="font-display font-semibold">{profile.name}</p>
          <p className="text-sm opacity-60">{profile.title}</p>
        </div>

        <div className="flex items-center gap-5">
          <a
            href={profile.github}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="GitHub"
            className="opacity-70 hover:opacity-100 hover:text-amber transition-colors"
          >
            <Github size={18} />
          </a>
          <a
            href={profile.linkedin}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="LinkedIn"
            className="opacity-70 hover:opacity-100 hover:text-amber transition-colors"
          >
            <Linkedin size={18} />
          </a>
          <a
            href={`mailto:${profile.email}`}
            aria-label="Email"
            className="opacity-70 hover:opacity-100 hover:text-amber transition-colors"
          >
            <Mail size={18} />
          </a>
        </div>

        <p className="text-sm opacity-50">© 2026 {profile.name}</p>
      </div>
    </footer>
  );
}
