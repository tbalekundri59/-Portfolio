import { Award } from 'lucide-react';
import achievements from '../data/achievements.js';

export default function Achievements() {
  return (
    <section id="achievements" className="py-24 bg-ink-900/[0.02] dark:bg-paper-100/[0.02]">
      <div className="max-w-content mx-auto px-6 lg:px-10">
        <h2 className="font-display font-bold text-3xl lg:text-4xl">Achievements</h2>

        <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {achievements.map((item) => (
            <div
              key={item.title}
              className="reveal border border-ink-700/15 dark:border-paper-100/15 rounded-lg p-5 flex gap-3"
            >
              <Award size={20} className="text-amber shrink-0 mt-0.5" />
              <div>
                <h3 className="font-display font-semibold text-base leading-snug">
                  {item.title}
                </h3>
                <p className="text-sm text-teal mt-1">{item.organization}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
