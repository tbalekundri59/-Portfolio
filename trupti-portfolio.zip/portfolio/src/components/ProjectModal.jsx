import { useEffect } from 'react';
import { X, Github, ExternalLink } from 'lucide-react';

export default function ProjectModal({ project, onClose }) {
  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && onClose();
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [onClose]);

  return (
    <div
      className="fixed inset-0 z-[60] flex items-start justify-center overflow-y-auto bg-ink-950/70 backdrop-blur-sm px-4 py-10"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label={`${project.name} project details`}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="bg-paper-50 dark:bg-ink-900 border border-ink-700/15 dark:border-paper-100/15 rounded-lg max-w-3xl w-full p-7 lg:p-10 relative"
      >
        <button
          onClick={onClose}
          aria-label="Close project details"
          className="absolute top-5 right-5 p-1.5 rounded hover:bg-ink-700/10 dark:hover:bg-paper-100/10"
        >
          <X size={20} />
        </button>

        <h3 className="font-display font-bold text-2xl lg:text-3xl pr-8">{project.name}</h3>
        <p className="font-mono text-sm text-teal mt-1">{project.subtitle}</p>

        <div className="flex items-center gap-4 mt-5 text-sm">
          <ModalLink href={project.githubUrl} icon={<Github size={15} />} label="View code" />
          <ModalLink href={project.liveUrl} icon={<ExternalLink size={15} />} label="Live demo" />
        </div>

        <Section title="Overview">{project.overview}</Section>
        <Section title="Problem">{project.problem}</Section>
        <Section title="Solution">{project.solution}</Section>

        <Section title="Architecture">
          <div className="flex flex-wrap items-center gap-2 font-mono text-xs">
            {project.architecture.map((layer, i) => (
              <span key={layer.layer} className="flex items-center gap-2">
                <span className="px-3 py-1.5 rounded border border-ink-700/20 dark:border-paper-100/20">
                  <span className="font-semibold">{layer.layer}:</span>{' '}
                  <span className="opacity-60">{layer.detail}</span>
                </span>
                {i < project.architecture.length - 1 && (
                  <span className="opacity-40">→</span>
                )}
              </span>
            ))}
          </div>
        </Section>

        <Section title="Technologies">
          <div className="flex flex-wrap gap-2">
            {project.tech.map((t) => (
              <span
                key={t}
                className="text-xs font-mono px-2.5 py-1 rounded border border-ink-700/15 dark:border-paper-100/15"
              >
                {t}
              </span>
            ))}
          </div>
        </Section>

        <Section title="Features">
          <ul className="grid sm:grid-cols-2 gap-x-6 gap-y-2">
            {project.features.map((f) => (
              <li key={f} className="flex gap-2 text-sm opacity-85">
                <span className="mt-2 w-1 h-1 rounded-full bg-current opacity-40 shrink-0" />
                {f}
              </li>
            ))}
          </ul>
        </Section>

        <Section title="Database">{project.database}</Section>
        <Section title="Challenges">{project.challenges}</Section>

        <Section title="What I learned">
          <ul className="space-y-1.5">
            {project.learnings.map((l) => (
              <li key={l} className="flex gap-2 text-sm opacity-85">
                <span className="mt-2 w-1 h-1 rounded-full bg-current opacity-40 shrink-0" />
                {l}
              </li>
            ))}
          </ul>
        </Section>
      </div>
    </div>
  );
}

function Section({ title, children }) {
  return (
    <div className="mt-7">
      <h4 className="font-mono text-sm opacity-50 mb-2.5">// {title.toLowerCase()}</h4>
      <div className="text-sm leading-relaxed opacity-90">{children}</div>
    </div>
  );
}

function ModalLink({ href, icon, label }) {
  if (!href) {
    return (
      <span className="inline-flex items-center gap-1.5 opacity-35 cursor-not-allowed">
        {icon} {label}
      </span>
    );
  }
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className="inline-flex items-center gap-1.5 text-amber hover:underline"
    >
      {icon} {label}
    </a>
  );
}
