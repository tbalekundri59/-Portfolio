const layers = [
  { label: 'Frontend', detail: 'Thymeleaf · HTML/CSS · JS' },
  { label: 'Controller', detail: 'Spring MVC' },
  { label: 'Service', detail: 'Business logic' },
  { label: 'Repository', detail: 'Spring Data JPA · Hibernate' },
  { label: 'Database', detail: 'MySQL' },
];

// The signature hero visual: a stacked layered-architecture diagram,
// pulled directly from the MVC / layered-architecture pattern described
// throughout the resume and both projects — not a generic dev illustration.
export default function ArchitectureDiagram() {
  const rowHeight = 62;
  const gap = 16;
  const width = 380;
  const height = layers.length * rowHeight + (layers.length - 1) * gap + 24;

  return (
    <svg
      viewBox={`0 0 ${width} ${height}`}
      className="w-full h-auto max-w-sm"
      role="img"
      aria-label="Layered application architecture: frontend, controller, service, repository, and database"
    >
      <defs>
        <marker id="arrow" markerWidth="8" markerHeight="8" refX="4" refY="4" orient="auto">
          <path d="M0,0 L8,4 L0,8 Z" className="fill-amber" />
        </marker>
      </defs>

      {layers.map((layer, i) => {
        const y = 12 + i * (rowHeight + gap);
        const isDb = i === layers.length - 1;
        return (
          <g key={layer.label}>
            <rect
              x="0"
              y={y}
              width={width}
              height={rowHeight}
              rx="3"
              className={
                isDb
                  ? 'fill-teal/10 stroke-teal/60'
                  : 'fill-ink-900/40 dark:fill-paper-100/[0.04] stroke-ink-700/60 dark:stroke-paper-100/20'
              }
              strokeWidth="1"
            />
            <text
              x="20"
              y={y + 26}
              className="fill-current text-[15px] font-display font-semibold"
            >
              {layer.label}
            </text>
            <text
              x="20"
              y={y + 46}
              className="fill-current opacity-60 text-[11px] font-mono"
            >
              {layer.detail}
            </text>

            {i < layers.length - 1 && (
              <line
                x1={width / 2}
                y1={y + rowHeight}
                x2={width / 2}
                y2={y + rowHeight + gap}
                className="stroke-amber"
                strokeWidth="1.5"
                markerEnd="url(#arrow)"
              />
            )}
          </g>
        );
      })}
    </svg>
  );
}
