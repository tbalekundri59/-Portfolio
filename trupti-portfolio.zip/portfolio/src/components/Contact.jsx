import { useState } from 'react';
import { Mail, Github, Linkedin, MapPin, Send } from 'lucide-react';
import profile from '../data/profile.js';

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', message: '' });

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();
    const subject = encodeURIComponent(`Portfolio inquiry from ${form.name || 'a recruiter'}`);
    const body = encodeURIComponent(
      `${form.message}\n\n— ${form.name}\n${form.email}`
    );
    window.location.href = `mailto:${profile.email}?subject=${subject}&body=${body}`;
  };

  return (
    <section id="contact" className="py-24">
      <div className="max-w-content mx-auto px-6 lg:px-10">
        <div className="text-center max-w-xl mx-auto">
          <h2 className="font-display font-bold text-3xl lg:text-4xl">
            Interested in working with me?
          </h2>
          <p className="mt-3 opacity-70">
            Explore my projects, experience, and technical skills, or download
            my resume to learn more.
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-4">
            <a
              href={profile.resumeFile}
              download
              className="inline-flex items-center gap-2 bg-amber text-ink-950 font-medium px-5 py-2.5 rounded hover:bg-amber-soft transition-colors"
            >
              Download Resume
            </a>
            <a
              href={`mailto:${profile.email}`}
              className="inline-flex items-center gap-2 border border-ink-700/30 dark:border-paper-100/25 font-medium px-5 py-2.5 rounded hover:border-amber hover:text-amber transition-colors"
            >
              Contact Me
            </a>
          </div>
        </div>

        <div className="mt-16 grid lg:grid-cols-[0.8fr_1.2fr] gap-12">
          <div>
            <h3 className="font-display font-semibold text-xl">{profile.name}</h3>
            <div className="mt-4 space-y-3 text-sm">
              <ContactRow icon={<Mail size={16} />} href={`mailto:${profile.email}`}>
                {profile.email}
              </ContactRow>
              <ContactRow icon={<MapPin size={16} />}>{profile.location}</ContactRow>
              <ContactRow icon={<Github size={16} />} href={profile.github} external>
                GitHub
              </ContactRow>
              <ContactRow icon={<Linkedin size={16} />} href={profile.linkedin} external>
                LinkedIn
              </ContactRow>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label htmlFor="name" className="block text-sm font-mono opacity-60 mb-1.5">
                  Name
                </label>
                <input
                  id="name"
                  name="name"
                  type="text"
                  required
                  value={form.name}
                  onChange={handleChange}
                  className="w-full bg-transparent border border-ink-700/25 dark:border-paper-100/20 rounded px-3 py-2.5 text-sm focus:border-amber outline-none"
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-mono opacity-60 mb-1.5">
                  Email
                </label>
                <input
                  id="email"
                  name="email"
                  type="email"
                  required
                  value={form.email}
                  onChange={handleChange}
                  className="w-full bg-transparent border border-ink-700/25 dark:border-paper-100/20 rounded px-3 py-2.5 text-sm focus:border-amber outline-none"
                />
              </div>
            </div>
            <div>
              <label htmlFor="message" className="block text-sm font-mono opacity-60 mb-1.5">
                Message
              </label>
              <textarea
                id="message"
                name="message"
                rows={5}
                required
                value={form.message}
                onChange={handleChange}
                className="w-full bg-transparent border border-ink-700/25 dark:border-paper-100/20 rounded px-3 py-2.5 text-sm focus:border-amber outline-none resize-none"
              />
            </div>
            <button
              type="submit"
              className="inline-flex items-center gap-2 bg-amber text-ink-950 font-medium px-5 py-2.5 rounded hover:bg-amber-soft transition-colors"
            >
              Send Message <Send size={15} />
            </button>
            <p className="text-xs opacity-50 pt-1">
              Opens your email client with this message pre-filled. To send
              messages directly from the form without an email client,
              connect it to a service like{' '}
              <a href="https://formspree.io" target="_blank" rel="noopener noreferrer" className="underline hover:text-amber">
                Formspree
              </a>{' '}
              or{' '}
              <a href="https://www.emailjs.com" target="_blank" rel="noopener noreferrer" className="underline hover:text-amber">
                EmailJS
              </a>{' '}
              (see README).
            </p>
          </form>
        </div>
      </div>
    </section>
  );
}

function ContactRow({ icon, children, href, external }) {
  const content = (
    <span className="flex items-center gap-2.5 opacity-80 hover:opacity-100 hover:text-amber transition-colors">
      {icon} {children}
    </span>
  );
  if (!href) return <div>{content}</div>;
  return (
    <a href={href} target={external ? '_blank' : undefined} rel={external ? 'noopener noreferrer' : undefined}>
      {content}
    </a>
  );
}
