import { Github, Linkedin, Mail, ArrowUpRight } from 'lucide-react';
import profile from '../data/profile.js';
import ArchitectureDiagram from './ArchitectureDiagram.jsx';

export default function Hero() {
  return (
    <section id="home" className="relative pt-32 pb-20 lg:pt-40 lg:pb-28 overflow-hidden">
      <div className="max-w-content mx-auto px-6 lg:px-10 grid lg:grid-cols-[1.1fr_0.9fr] gap-16 items-center">
        <div>
          <p
            className="font-mono text-sm text-teal opacity-0 animate-[fadeIn_0.6s_ease_forwards]"
            style={{ animationDelay: '0.05s' }}
          >
            {profile.location}
          </p>

          <h1
            className="mt-4 font-display font-bold text-4xl sm:text-5xl lg:text-6xl leading-[1.08] tracking-tight opacity-0 animate-[fadeUp_0.7s_ease_forwards]"
            style={{ animationDelay: '0.15s' }}
          >
            {profile.name}
          </h1>

          <p
            className="mt-4 font-display text-xl lg:text-2xl text-amber opacity-0 animate-[fadeUp_0.7s_ease_forwards]"
            style={{ animationDelay: '0.28s' }}
          >
            {profile.title}
          </p>

          <p
            className="mt-2 text-base opacity-70 opacity-0 animate-[fadeUp_0.7s_ease_forwards]"
            style={{ animationDelay: '0.36s' }}
          >
            {profile.tagline}, building with Java, Spring Boot, MySQL, and REST APIs
          </p>

          <p
            className="mt-6 max-w-xl text-base leading-relaxed opacity-80 opacity-0 animate-[fadeUp_0.7s_ease_forwards]"
            style={{ animationDelay: '0.46s' }}
          >
            Building Java full-stack applications with Spring Boot, Spring MVC,
            Hibernate/JPA, JDBC, MySQL, and REST APIs — following MVC and
            layered architecture, with hands-on exposure to Linux, Docker,
            and CI/CD.
          </p>

          <div
            className="mt-8 flex flex-wrap items-center gap-4 opacity-0 animate-[fadeUp_0.7s_ease_forwards]"
            style={{ animationDelay: '0.56s' }}
          >
            <a
              href="#projects"
              className="inline-flex items-center gap-2 bg-amber text-ink-950 font-medium px-5 py-2.5 rounded hover:bg-amber-soft transition-colors"
            >
              View Projects <ArrowUpRight size={16} />
            </a>
            <a
              href={profile.resumeFile}
              download
              className="inline-flex items-center gap-2 border border-ink-700/30 dark:border-paper-100/25 font-medium px-5 py-2.5 rounded hover:border-amber hover:text-amber transition-colors"
            >
              Download Resume
            </a>
          </div>

          <div
            className="mt-8 flex items-center gap-5 opacity-0 animate-[fadeUp_0.7s_ease_forwards]"
            style={{ animationDelay: '0.64s' }}
          >
            <a
              href={profile.github}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="GitHub"
              className="opacity-70 hover:opacity-100 hover:text-amber transition-colors"
            >
              <Github size={20} />
            </a>
            <a
              href={profile.linkedin}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="LinkedIn"
              className="opacity-70 hover:opacity-100 hover:text-amber transition-colors"
            >
              <Linkedin size={20} />
            </a>
            <a
              href={`mailto:${profile.email}`}
              aria-label="Email"
              className="opacity-70 hover:opacity-100 hover:text-amber transition-colors"
            >
              <Mail size={20} />
            </a>
          </div>
        </div>

        <div
          className="flex justify-center lg:justify-end opacity-0 animate-[fadeIn_0.9s_ease_forwards]"
          style={{ animationDelay: '0.4s' }}
        >
          <ArchitectureDiagram />
        </div>
      </div>

      <style>{`
        @keyframes fadeUp {
          from { opacity: 0; transform: translateY(16px); }
          to { opacity: 1; transform: translateY(0); }
        }
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @media (prefers-reduced-motion: reduce) {
          #home [style*="animation"] { animation: none !important; opacity: 1 !important; }
        }
      `}</style>
    </section>
  );
}
