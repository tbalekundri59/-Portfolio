import { useEffect, useState } from 'react';
import { Github, Linkedin, FileText, Menu, X, Moon, Sun } from 'lucide-react';
import profile from '../data/profile.js';

const links = [
  { href: '#home', label: 'Home' },
  { href: '#about', label: 'About' },
  { href: '#skills', label: 'Skills' },
  { href: '#experience', label: 'Experience' },
  { href: '#projects', label: 'Projects' },
  { href: '#certifications', label: 'Certifications' },
  { href: '#achievements', label: 'Achievements' },
  { href: '#contact', label: 'Contact' },
];

export default function Navbar({ theme, toggleTheme }) {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [open]);

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-colors duration-300 ${
        scrolled
          ? 'bg-paper-50/90 dark:bg-ink-950/90 backdrop-blur border-b border-ink-700/10 dark:border-paper-100/10'
          : 'bg-transparent'
      }`}
    >
      <nav className="max-w-content mx-auto px-6 lg:px-10 flex items-center justify-between h-16">
        <a
          href="#home"
          className="font-display font-semibold text-base tracking-tight"
        >
          Trupti<span className="text-amber">.</span>dev
        </a>

        <ul className="hidden lg:flex items-center gap-8 font-body text-sm">
          {links.map((link) => (
            <li key={link.href}>
              <a
                href={link.href}
                className="opacity-75 hover:opacity-100 hover:text-amber transition-colors"
              >
                {link.label}
              </a>
            </li>
          ))}
        </ul>

        <div className="hidden lg:flex items-center gap-4">
          <IconLink href={profile.github} label="GitHub">
            <Github size={18} />
          </IconLink>
          <IconLink href={profile.linkedin} label="LinkedIn">
            <Linkedin size={18} />
          </IconLink>
          <a
            href={profile.resumeFile}
            download
            className="flex items-center gap-1.5 text-sm border border-ink-700/30 dark:border-paper-100/25 rounded px-3 py-1.5 hover:border-amber hover:text-amber transition-colors"
          >
            <FileText size={16} /> Resume
          </a>
          <button
            onClick={toggleTheme}
            aria-label="Toggle color theme"
            className="p-2 rounded border border-ink-700/30 dark:border-paper-100/25 hover:border-amber hover:text-amber transition-colors"
          >
            {theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />}
          </button>
        </div>

        <button
          className="lg:hidden p-2"
          onClick={() => setOpen((o) => !o)}
          aria-label={open ? 'Close menu' : 'Open menu'}
          aria-expanded={open}
        >
          {open ? <X size={22} /> : <Menu size={22} />}
        </button>
      </nav>

      {open && (
        <div className="lg:hidden bg-paper-50 dark:bg-ink-950 border-t border-ink-700/10 dark:border-paper-100/10 px-6 pb-8 pt-2">
          <ul className="flex flex-col gap-1 font-body">
            {links.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  onClick={() => setOpen(false)}
                  className="block py-3 border-b border-ink-700/10 dark:border-paper-100/10 opacity-80 hover:text-amber"
                >
                  {link.label}
                </a>
              </li>
            ))}
          </ul>
          <div className="flex items-center gap-4 mt-5">
            <IconLink href={profile.github} label="GitHub">
              <Github size={20} />
            </IconLink>
            <IconLink href={profile.linkedin} label="LinkedIn">
              <Linkedin size={20} />
            </IconLink>
            <a
              href={profile.resumeFile}
              download
              className="flex items-center gap-1.5 text-sm border border-ink-700/30 dark:border-paper-100/25 rounded px-3 py-1.5"
            >
              <FileText size={16} /> Resume
            </a>
            <button
              onClick={toggleTheme}
              aria-label="Toggle color theme"
              className="p-2 rounded border border-ink-700/30 dark:border-paper-100/25 ml-auto"
            >
              {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
            </button>
          </div>
        </div>
      )}
    </header>
  );
}

function IconLink({ href, label, children }) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={label}
      className="p-2 rounded border border-ink-700/30 dark:border-paper-100/25 hover:border-amber hover:text-amber transition-colors"
    >
      {children}
    </a>
  );
}
