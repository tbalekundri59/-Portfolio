import { useState } from 'react';
import { FileText, ExternalLink } from 'lucide-react';
import certifications from '../data/certifications.js';
import CertificateModal from './CertificateModal.jsx';

export default function Certifications() {
  const [activeIndex, setActiveIndex] = useState(null);

  return (
    <section id="certifications" className="py-24 spine">
      <div className="max-w-content mx-auto px-6 lg:px-10 pl-10 lg:pl-14 relative">
        <span className="spine-node" style={{ top: 6 }} />
        <h2 className="font-display font-bold text-3xl lg:text-4xl">Certifications</h2>
        <p className="mt-3 opacity-70 max-w-xl">
          Verified completion certificates — click any card to open the original document.
        </p>

        <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {certifications.map((cert, i) => (
            <button
              key={cert.title}
              onClick={() => setActiveIndex(i)}
              className="reveal text-left border border-ink-700/15 dark:border-paper-100/15 rounded-lg p-5 hover:border-amber/60 transition-colors group"
            >
              <div className="w-full aspect-[4/3] rounded border border-ink-700/10 dark:border-paper-100/10 bg-ink-900/[0.03] dark:bg-paper-100/[0.03] flex items-center justify-center mb-4">
                <FileText size={32} className="opacity-40 group-hover:text-amber group-hover:opacity-100 transition-colors" />
              </div>
              <h3 className="font-display font-semibold text-base leading-snug">{cert.title}</h3>
              <p className="text-sm text-teal mt-1">{cert.organization}</p>
              <p className="font-mono text-xs opacity-60 mt-2">{cert.date}</p>

              <span className="inline-flex items-center gap-1.5 text-sm text-amber mt-4 group-hover:gap-2.5 transition-all">
                View certificate <ExternalLink size={13} />
              </span>
            </button>
          ))}
        </div>
      </div>

      {activeIndex !== null && (
        <CertificateModal
          certifications={certifications}
          index={activeIndex}
          setIndex={setActiveIndex}
          onClose={() => setActiveIndex(null)}
        />
      )}
    </section>
  );
}
