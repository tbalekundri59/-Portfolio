import { useEffect } from 'react';
import { X, ChevronLeft, ChevronRight, Download } from 'lucide-react';

export default function CertificateModal({ certifications, index, setIndex, onClose }) {
  const cert = certifications[index];
  const isPdf = cert.certificateFile.toLowerCase().endsWith('.pdf');

  useEffect(() => {
    const onKey = (e) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight') setIndex((i) => (i + 1) % certifications.length);
      if (e.key === 'ArrowLeft') setIndex((i) => (i - 1 + certifications.length) % certifications.length);
    };
    document.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [onClose, setIndex, certifications.length]);

  return (
    <div
      className="fixed inset-0 z-[60] flex flex-col bg-ink-950/90 backdrop-blur-sm"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label={`${cert.title} certificate viewer`}
    >
      <div
        className="flex items-center justify-between px-5 py-4 text-paper-100"
        onClick={(e) => e.stopPropagation()}
      >
        <div>
          <h3 className="font-display font-semibold text-base">{cert.title}</h3>
          <p className="text-sm opacity-70">{cert.organization}</p>
        </div>
        <div className="flex items-center gap-2">
          <a
            href={cert.certificateFile}
            download
            aria-label="Download certificate"
            className="p-2 rounded hover:bg-paper-100/10"
          >
            <Download size={20} />
          </a>
          <button onClick={onClose} aria-label="Close" className="p-2 rounded hover:bg-paper-100/10">
            <X size={22} />
          </button>
        </div>
      </div>

      <div
        className="flex-1 relative flex items-center justify-center px-4 pb-6"
        onClick={(e) => e.stopPropagation()}
      >
        {certifications.length > 1 && (
          <>
            <NavButton
              side="left"
              onClick={() => setIndex((i) => (i - 1 + certifications.length) % certifications.length)}
            />
            <NavButton
              side="right"
              onClick={() => setIndex((i) => (i + 1) % certifications.length)}
            />
          </>
        )}

        <div className="w-full h-full max-w-4xl bg-paper-50 rounded-lg overflow-hidden">
          {isPdf ? (
            <iframe
              src={cert.certificateFile}
              title={cert.title}
              className="w-full h-[75vh]"
            />
          ) : (
            <img
              src={cert.certificateFile}
              alt={`${cert.title} certificate`}
              className="w-full h-[75vh] object-contain bg-paper-50"
            />
          )}
        </div>
      </div>
    </div>
  );
}

function NavButton({ side, onClick }) {
  return (
    <button
      onClick={onClick}
      aria-label={side === 'left' ? 'Previous certificate' : 'Next certificate'}
      className={`hidden sm:flex absolute ${
        side === 'left' ? 'left-3' : 'right-3'
      } top-1/2 -translate-y-1/2 z-10 p-2 rounded-full bg-paper-50/10 text-paper-100 hover:bg-paper-50/20`}
    >
      {side === 'left' ? <ChevronLeft size={24} /> : <ChevronRight size={24} />}
    </button>
  );
}
