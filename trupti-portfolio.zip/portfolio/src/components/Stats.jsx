import profile from '../data/profile.js';

export default function Stats() {
  return (
    <section className="border-y border-ink-700/10 dark:border-paper-100/10">
      <div className="max-w-content mx-auto px-6 lg:px-10 grid grid-cols-2 sm:grid-cols-4">
        {profile.stats.map((stat, i) => (
          <div
            key={stat.label}
            className={`py-8 text-center sm:text-left ${
              i > 0 ? 'border-l border-ink-700/10 dark:border-paper-100/10 pl-6' : ''
            }`}
          >
            <div className="font-display font-bold text-3xl lg:text-4xl">{stat.value}</div>
            <div className="mt-1 font-mono text-sm opacity-60">{stat.label}</div>
          </div>
        ))}
      </div>
    </section>
  );
}
