import skills from '../data/skills.js';

export default function Skills() {
  return (
    <section id="skills" className="py-24 spine bg-ink-900/[0.02] dark:bg-paper-100/[0.02]">
      <div className="max-w-content mx-auto px-6 lg:px-10 pl-10 lg:pl-14 relative">
        <span className="spine-node" style={{ top: 6 }} />
        <h2 className="font-display font-bold text-3xl lg:text-4xl">Technical Skills</h2>
        <p className="mt-3 opacity-70 max-w-xl">
          Organized by where each technology sits in the applications I build.
        </p>

        <div className="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {skills.map((group) => (
            <div
              key={group.category}
              className="reveal border border-ink-700/15 dark:border-paper-100/15 rounded-lg p-5"
            >
              <h3 className="font-mono text-sm text-teal mb-3">// {group.category.toLowerCase()}</h3>
              <div className="flex flex-wrap gap-2">
                {group.items.map((item) => (
                  <span
                    key={item}
                    className="text-sm px-2.5 py-1 rounded border border-ink-700/15 dark:border-paper-100/15 hover:border-amber hover:text-amber transition-colors"
                  >
                    {item}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
