import { MapPin } from 'lucide-react';
import experience from '../data/experience.js';

export default function Experience() {
  return (
    <section id="experience" className="py-24">
      <div className="max-w-content mx-auto px-6 lg:px-10">
        <h2 className="font-display font-bold text-3xl lg:text-4xl">Experience</h2>

        <div className="mt-12 relative pl-8">
          <div className="absolute left-[5px] top-2 bottom-2 w-px bg-ink-700/15 dark:bg-paper-100/15" />

          <div className="space-y-14">
            {experience.map((job) => (
              <div key={job.role} className="reveal relative">
                <span className="absolute -left-8 top-1.5 w-[11px] h-[11px] rounded-sm bg-amber" />

                <div className="flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1">
                  <h3 className="font-display font-semibold text-xl">{job.role}</h3>
                  <span className="font-mono text-xs opacity-60">{job.duration}</span>
                </div>

                <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-sm opacity-75">
                  <span className="text-teal font-medium">{job.company}</span>
                  {job.location && (
                    <span className="flex items-center gap-1">
                      <MapPin size={13} /> {job.location}
                    </span>
                  )}
                </div>

                <ul className="mt-4 space-y-2 max-w-2xl">
                  {job.points.map((point) => (
                    <li key={point} className="flex gap-3 text-sm leading-relaxed opacity-85">
                      <span className="mt-2 w-1 h-1 rounded-full bg-current opacity-40 shrink-0" />
                      {point}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
