// Skill categories — sourced directly from the resume's Technical Skills section.
const skills = [
  {
    category: 'Programming',
    items: ['Java'],
  },
  {
    category: 'Frontend',
    items: ['HTML', 'CSS', 'JavaScript', 'Thymeleaf', 'Bootstrap'],
  },
  {
    category: 'Backend',
    items: ['Spring Boot', 'Spring MVC', 'Spring Data JPA', 'Hibernate', 'JDBC'],
  },
  {
    category: 'Database',
    items: ['MySQL', 'SQL'],
  },
  {
    category: 'Development',
    items: ['REST APIs', 'MVC Architecture', 'Layered Architecture', 'CRUD Operations', 'OOP'],
  },
  {
    category: 'DevOps & Tools',
    items: ['Git', 'GitHub', 'Docker', 'Linux', 'CI/CD', 'VS Code', 'Eclipse', 'IntelliJ IDEA'],
  },
];

export default skills;
