// Project data — sourced directly from the resume.
// Replace githubUrl / liveUrl placeholders with real links when available.
const projects = [
  {
    id: 'factorypulse',
    name: 'FactoryPulse',
    subtitle: 'Smart Factory Monitoring System',
    description:
      'Full-stack smart factory monitoring application designed to manage factory operations, machine monitoring, production activities, employee management, and maintenance scheduling.',
    tech: ['Java', 'Spring Boot', 'Spring MVC', 'Hibernate/JPA', 'Thymeleaf', 'MySQL', 'HTML', 'CSS', 'Bootstrap', 'JavaScript'],
    features: [
      'Secure authentication and role-based access for administrators',
      'Machine monitoring module',
      'Production management module',
      'Employee management module',
      'Maintenance scheduling module',
      'Responsive dashboards with dynamic data visualization',
      'Complete CRUD operations',
      'MySQL integration via Spring Data JPA',
    ],
    architecture: [
      { layer: 'Frontend', detail: 'Thymeleaf, HTML, CSS, JavaScript, Bootstrap' },
      { layer: 'Controller', detail: 'Spring MVC' },
      { layer: 'Service', detail: 'Business logic layer' },
      { layer: 'Repository', detail: 'Spring Data JPA / Hibernate' },
      { layer: 'Database', detail: 'MySQL' },
    ],
    overview:
      'FactoryPulse is a full-stack web application built to give factory administrators a single place to monitor machines, track production activity, manage employees, and schedule maintenance.',
    problem:
      'Factory operations involve several moving parts — machine status, production output, staffing, and maintenance — that are hard to track without a centralized, structured system.',
    solution:
      'The application follows a layered MVC architecture: Thymeleaf-rendered views communicate with Spring MVC controllers, which delegate to a service layer, which in turn uses Spring Data JPA repositories to persist and retrieve data from MySQL. Role-based access restricts sensitive operations to administrators.',
    database:
      'Spring Data JPA and Hibernate/JPA map application entities (machines, production records, employees, maintenance schedules) to MySQL tables, with the repository layer handling CRUD operations.',
    challenges:
      'Coordinating multiple modules (machine monitoring, production, employee management, maintenance) within one layered architecture required keeping the controller, service, and repository layers cleanly separated so each module stayed maintainable as functionality grew.',
    learnings: [
      'Structuring a multi-module Spring Boot application around MVC and layered architecture',
      'Implementing authentication and role-based access control',
      'Building responsive dashboards with dynamic data using Thymeleaf, Bootstrap, and JavaScript',
      'Managing relational data with Spring Data JPA and MySQL',
    ],
    githubUrl: null,
    liveUrl: null,
  },
  {
    id: 'resume-builder-pro',
    name: 'Resume Builder Pro',
    subtitle: 'Full-Stack Resume Builder Application',
    description:
      'Full-stack resume builder application allowing users to register, authenticate, create, edit, preview, and manage professional resumes.',
    tech: ['Java', 'Spring Boot', 'Spring MVC', 'JDBC', 'Hibernate/JPA', 'MySQL', 'Thymeleaf', 'HTML', 'CSS', 'Bootstrap', 'JavaScript'],
    features: [
      'User registration',
      'Authentication and session management',
      'Resume creation, editing, and preview',
      'CRUD operations for resume data',
      'Form validation',
      'Dynamic resume generation',
      'ATS-friendly interface',
      'MySQL integration',
    ],
    architecture: [
      { layer: 'Frontend', detail: 'Thymeleaf, HTML, CSS, JavaScript, Bootstrap' },
      { layer: 'Controller', detail: 'Spring MVC' },
      { layer: 'Service', detail: 'Business logic layer' },
      { layer: 'Repository', detail: 'JDBC + Hibernate/JPA' },
      { layer: 'Database', detail: 'MySQL' },
    ],
    overview:
      'Resume Builder Pro lets users register, log in, and build professional resumes through a guided, ATS-friendly web interface, with full control to edit and preview their resume before download.',
    problem:
      'Building a clean, ATS-friendly resume from scratch is time-consuming, and many tools do not give users full control over structure and content.',
    solution:
      'The application uses Spring MVC controllers backed by a service layer, with JDBC and Hibernate/JPA handling persistence to MySQL. Session management keeps each user\'s resume data scoped to their account, while Thymeleaf templates render a responsive, ATS-friendly interface.',
    database:
      'User accounts and resume records are persisted in MySQL, accessed through a combination of JDBC and Hibernate/JPA, following MVC architecture.',
    challenges:
      'Supporting create, edit, and preview flows for the same resume data meant designing form validation and session management carefully so dynamically generated resumes stayed consistent across each step.',
    learnings: [
      'Implementing authentication and session management in a Spring Boot application',
      'Designing CRUD flows with form validation',
      'Generating dynamic content with Thymeleaf templates',
      'Structuring a maintainable, modular project for scalability',
    ],
    githubUrl: null,
    liveUrl: null,
  },
];

export default projects;
