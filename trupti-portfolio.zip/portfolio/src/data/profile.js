// Centralized profile configuration.
// Update the links below with your actual profiles.
const profile = {
  name: 'Trupti Balekundri',
  title: 'Java Full Stack Developer',
  tagline: 'Computer Science Engineering Graduate',
  location: 'Belgaum, Karnataka, India',
  phone: '+91-7483308789',
  email: 'truptibalekundri59@gmail.com',
  github: 'https://github.com/tbalekundri59',
  linkedin: 'https://www.linkedin.com/in/trupti-balekundri-97779a284/',
  resumeFile: '/resume/trupti-balekundri-resume.pdf',
  summary:
    'Computer Science Engineering graduate with hands-on experience developing Java full-stack applications using Java, Spring Boot, Spring MVC, Hibernate/JPA, JDBC, MySQL, Thymeleaf, HTML, CSS, JavaScript, and REST APIs. Experienced in MVC and layered architectures, database integration, CRUD operations, authentication, and Git-based development. Additional exposure to Linux, Docker, CI/CD pipelines, and cloud DevOps workflows. Seeking an entry-level Java Full Stack Developer role.',
  education: {
    degree: 'Bachelor of Engineering in Computer Science',
    institute: 'Angadi Institute of Technology and Management',
    location: 'Belgaum, Karnataka',
    cgpa: '8.1/10',
    duration: '2022 – 2026',
  },
  stats: [
    { value: '8.1/10', label: 'CGPA' },
    { value: '2026', label: 'Graduation' },
    { value: '2', label: 'Internships' },
    { value: '2', label: 'Major Projects' },
  ],
};

export default profile;
