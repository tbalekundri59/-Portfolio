// Internship experience — sourced directly from the resume.
const experience = [
  {
    role: 'Java Full Stack Intern',
    company: 'Tap Academy',
    location: 'Bengaluru, Karnataka',
    duration: 'Feb 2026 – Aug 2026',
    points: [
      'Developed Java-based web applications using Java, JDBC, Servlets, Spring Boot, SQL, HTML, CSS, and JavaScript with database connectivity.',
      'Applied Object-Oriented Programming concepts while building practical full-stack applications and backend functionality.',
      'Implemented responsive web interfaces and integrated application components with relational databases.',
    ],
  },
  {
    role: 'Cloud DevOps with AI Intern',
    company: 'Softmusk Info Pvt. Ltd.',
    location: null,
    duration: 'Jan 2026 – May 2026',
    points: [
      'Worked with Linux, Git, Docker, and CI/CD pipelines as part of cloud DevOps workflows.',
      'Gained hands-on exposure to cloud deployment automation and DevOps practices.',
      'Participated in AI-enabled cloud development projects and deployment-related activities.',
    ],
  },
];

export default experience;
