// Certification data — extracted only from the actual uploaded certificate files.
// Add new certificates by dropping the file into public/certificates/ and adding an entry here.
const certifications = [
  {
    title: 'Full Stack Web Development',
    organization: 'Tap Academy',
    date: '22.08.2026',
    credentialId: 'Cert. No. 16064 | Reg. No. TAJANC2C261043',
    certificateFile: '/certificates/java-full-stack-tap-academy.pdf',
    verificationUrl: null,
  },
  {
    title: 'Internship Certificate — Cloud DevOps with AI',
    organization: 'Softmusk Info Pvt. Ltd.',
    date: '27 Jan 2026 – 9 May 2026',
    credentialId: null,
    certificateFile: '/certificates/cloud-devops-softmusk.pdf',
    verificationUrl: null,
  },
];

export default certifications;
