// Achievements — sourced directly from the resume's Certifications & Achievements section.
const achievements = [
  {
    title: 'Robotics Hackathon',
    organization: 'Wefaa Robotics',
  },
  {
    title: 'BELPy — International Conference on Python',
    organization: 'BELPy',
  },
  {
    title: 'Aptitude, Soft Skills and Technical Skill Employability Enhancement Program',
    organization: 'Infosys Foundation',
  },
];

export default achievements;
