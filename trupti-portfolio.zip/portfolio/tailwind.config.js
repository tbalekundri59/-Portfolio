/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        ink: {
          950: '#0F1216',
          900: '#171B21',
          800: '#1E232B',
          700: '#2A3038',
        },
        paper: {
          50: '#F6F4EE',
          100: '#EDEAE1',
          200: '#E2DED2',
        },
        amber: {
          DEFAULT: '#E2A33D',
          soft: '#F0C378',
        },
        teal: {
          DEFAULT: '#3FA796',
          soft: '#6FC2B4',
        },
      },
      fontFamily: {
        display: ['Sora', 'sans-serif'],
        body: ['Inter', 'sans-serif'],
        mono: ['"IBM Plex Mono"', 'monospace'],
      },
      maxWidth: {
        content: '72rem',
      },
    },
  },
  plugins: [],
};
