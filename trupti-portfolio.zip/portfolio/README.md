# Trupti Balekundri — Portfolio

A recruiter-focused personal portfolio built with React, Vite, and Tailwind CSS. Every piece of content — summary, education, internships, projects, skills, and certifications — is sourced directly from the uploaded resume and certificate files. Nothing is invented; unavailable data is left as an explicit placeholder.

## Features

- Sticky, responsive navbar with GitHub / LinkedIn / Resume shortcuts and a mobile hamburger menu
- Animated hero with a custom layered-architecture diagram (Frontend → Controller → Service → Repository → Database)
- Quick stats, About section with a "Quick Facts" card
- Categorized technical skills grid
- Vertical experience timeline (both internships)
- Project cards with a detailed modal (overview, problem, solution, architecture, features, database, challenges, what I learned)
- Certificate gallery with a lightbox viewer (PDF/image, zoom via browser, next/prev, download)
- Achievements section
- Contact section with a `mailto:`-based form
- Dark mode (default) with light mode toggle, persisted in `localStorage`
- Scroll-reveal animations, respecting `prefers-reduced-motion`
- Semantic HTML, keyboard focus states, ARIA labels, SEO meta tags

## Tech stack

React 18 + Vite + Tailwind CSS + lucide-react icons.

## Installation

This environment has no internet access, so dependencies could not be pre-installed — install them on your machine:

```bash
npm install
```

## Running locally

```bash
npm run dev
```

Then open the printed local URL (typically `http://localhost:5173`).

## Building for production

```bash
npm run build
npm run preview   # optional: preview the production build locally
```

The build output goes to `dist/`.

## Folder structure

```text
portfolio/
├── public/
│   ├── certificates/        # certificate PDFs, shown in the Certifications gallery
│   ├── resume/               # your resume PDF, used by the "Download Resume" buttons
│   └── images/                # favicon + (add) social preview image
├── src/
│   ├── components/          # one component per section
│   ├── data/                  # all editable content lives here
│   │   ├── profile.js         # name, links, summary, education, stats
│   │   ├── skills.js
│   │   ├── experience.js
│   │   ├── projects.js
│   │   ├── certifications.js
│   │   └── achievements.js
│   ├── hooks/                 # theme + scroll-reveal hooks
│   ├── App.jsx
│   ├── main.jsx
│   └── index.css
├── index.html
├── tailwind.config.js
└── package.json
```

## What you need to update before publishing

1. **GitHub link** — `src/data/profile.js` → `github`. Currently set to `https://github.com/tbalekundri59`.
2. **LinkedIn link** — `src/data/profile.js` → `linkedin`. Currently set to your provided LinkedIn URL.
3. **Project links** — `src/data/projects.js` → each project's `githubUrl` and `liveUrl` are currently `null` (rendered as a disabled, greyed-out link in the UI). Add the real repo/demo URLs once available; the button will activate automatically.
4. **Resume file** — already copied to `public/resume/trupti-balekundri-resume.pdf` from your upload and wired up in `profile.js`. Replace this file (keep the same name, or update `resumeFile` in `profile.js`) whenever you update your resume.
5. **Certificates** — already copied to `public/certificates/` from your two uploaded certificate files (Tap Academy, Softmusk Info). To add more, drop the file into `public/certificates/` and add an entry to `src/data/certifications.js`.
6. **Social preview image** — `index.html` currently points `og:image` at the favicon as a placeholder. For a proper link-preview image, add a 1200×630 image at `public/images/og-image.png` and update the `og:image` / `twitter:image` paths in `index.html`.
7. **Contact form backend** — the form currently opens the visitor's email client via `mailto:` with the message pre-filled (see `src/components/Contact.jsx`). To accept submissions directly without opening an email client, connect it to a form backend:
   - [Formspree](https://formspree.io) — replace the `handleSubmit` function with a `fetch` POST to your Formspree endpoint.
   - [EmailJS](https://www.emailjs.com) — install `@emailjs/browser` and call `emailjs.send(...)` in `handleSubmit`.

## Deployment

### Option 1 — Vercel

```bash
npm install -g vercel
vercel
```
Follow the prompts (build command `npm run build`, output directory `dist`).

### Option 2 — Netlify

```bash
npm install -g netlify-cli
npm run build
netlify deploy --prod --dir=dist
```

### Option 3 — GitHub Pages

1. Install the deploy helper: `npm install -D gh-pages`
2. Add to `package.json`:
   ```json
   "homepage": "https://<your-username>.github.io/<repo-name>",
   "scripts": {
     "predeploy": "npm run build",
     "deploy": "gh-pages -d dist"
   }
   ```
3. Run: `npm run deploy`

## Future improvements

- Add real GitHub/live-demo links per project
- Add a dedicated Open Graph preview image
- Wire the contact form to Formspree/EmailJS for direct submissions
- Add unit/e2e tests as the site grows
- Add more certificates and achievements as you earn them
